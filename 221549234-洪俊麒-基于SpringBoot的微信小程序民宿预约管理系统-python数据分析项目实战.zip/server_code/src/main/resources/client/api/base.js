﻿const base = {
    url : "http://localhost:8080/cl3338746/"
}
export default base
